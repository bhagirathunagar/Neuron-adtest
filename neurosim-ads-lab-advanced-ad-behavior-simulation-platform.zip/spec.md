# NeuroSim Ads Lab   Advanced Ad Behavior Simulation Platform

## Overview
NeuroSim Ads Lab is a simulation platform that models human behavioral responses to Facebook and Instagram ads. Users can upload ad creatives, configure targeting parameters, and receive AI-generated behavioral predictions and performance metrics.

## Core Features

### Authentication System
- **Fixed Internet Identity Integration**: Complete authentication flow with automatic initialization, retry logic, and session validation
- **Stable Authentication Hook**: Robust authentication state management with automatic retry up to 3 times using exponential backoff
- **Session Validation**: Backend endpoint to verify authenticated user session with timeout protection
- **Error Recovery**: Clear error messaging only after persistent authentication failures with refresh prompt option
- **Guaranteed Navigation**: Direct navigation to Project Setup or Dashboard after successful authentication with valid session context
- **Authentication State Persistence**: Reliable session state management across page refreshes and navigation

### Project Management
- Create projects with custom names
- Select industry from predefined options: Fashion Wholesale, Retail, Healthcare, Education, Real Estate, E-commerce, Local Services, SaaS, Finance, or Custom
- Manage multiple ads within each project
- **Critical Get Started Button Fix**: Complete debugging and repair of navigation workflow:
  - **Guaranteed Backend Readiness**: Mandatory backend health check with 500ms timeout before any operations
  - **Bulletproof State Management**: Loading state must reset correctly after all operations - no infinite spinners or blocked UI
  - **Verified Backend Connection**: Project load or create calls must succeed before navigation with comprehensive error catching
  - **Automatic Retry Mechanism**: Failed backend calls automatically retry up to 3 times with exponential backoff
  - **Guaranteed Navigation**: Navigate to ProjectSetup component only after verified successful backend operations
  - **Complete State Reset**: All loading and error states properly cleared regardless of operation outcome
  - **Maximum 2-Second Loading**: Hard timeout protection prevents stuck loading states
- **Enhanced Error Recovery**: User-friendly error messages with automatic retry options for all backend failures
- **Comprehensive Integration Testing**: Complete frontend-backend integration tests for all routes and button functionality

### Creative Testing
- Upload video creatives for each ad with proper file handling and backend storage
- Configure ad components with validated backend persistence:
  - Primary text content
  - Headline text
  - Call-to-action selection from dropdown options
  - Conversion destination (WhatsApp, Website, Instagram DM, Lead Form)
  - Conversion goal (Messages, Leads, Purchases, Traffic, Awareness)
- **Fixed Add Ad Functionality**: "Add Ad" button properly creates new ad entries with backend persistence

### Audience Simulation
- Define target demographics with backend validation:
  - Age groups: 18-24, 25-34, 35-44, 45-54, 55+
  - Gender: Male, Female, All
- Configure targeting parameters with proper data persistence:
  - Interests and behaviors
  - Demographics
  - Custom targeting inputs
- Set audience size (1K-100K range) with backend validation
- Select multiple target countries with proper storage, including India as an available option
- **Country Selection**: Multi-select dropdown supporting India alongside other countries, with proper backend persistence in the countries array
- **Navigation State Reset**: App.tsx navigation hook correctly resets state after adding new countries to maintain consistent navigation flow

### Advanced Human Behavior Engine
- **Fixed Simulation Integration**: "Run Simulation" button properly triggers behavioral analysis with:
  - Complete backend connection to simulation endpoints
  - Proper data flow from simulation.ts to visualization components
  - Reliable error handling for simulation failures
  - Loading states during simulation processing
- Generate realistic human behavioral responses using deep behavioral modeling:
  - **Attention decay modeling** with exponential decay functions based on age and creative engagement strength
  - **Emotional mapping** through text sentiment analysis and demographic psychology patterns
  - **Trust, fatigue, and cognitive load** calculations considering video length, ad tone, and CTA complexity
  - **Composite behavioral matrix** mapping age × gender × industry to define likelihood factors for emotional resonance, attention, and conversion intent
- Behavior modeling varies by demographics, industry, and platform context with demographically-specific responses

### Neuro-Metrics Generation
- **Fixed Metrics Pipeline**: Complete data flow from simulation output to dashboard visualization
- Calculate advanced behavioral scores (0-100%) with proper backend processing:
  - **Hook Strength** - Initial attention capture effectiveness
  - **Hold Rate** - Sustained attention throughout creative
  - **Cognitive Load** - Mental processing difficulty assessment
  - **Emotional Resonance** - Emotional connection strength
  - **Trust Level** - Credibility and trustworthiness perception
  - **Fatigue Risk** - Audience saturation likelihood
  - **Scroll-Stop Probability** - Likelihood to pause scrolling
  - **Outbound Intent Probability** - Conversion action likelihood
- Overall Performance Score (0-100%) based on weighted metric combination
- All scores normalized consistently for comparative analysis

### Enhanced Visualization Dashboard
- **Fixed Dashboard Integration**: Complete connection between simulation results and visualization components:
  - **AnalyticsDashboard** properly receives and displays simulation data with correct country display including India
  - **MetricsGauge** correctly renders performance scores with real-time updates
  - **AttentionDecayChart** displays attention timeline with proper data binding
  - **EmotionalHeatmap** shows sentiment analysis results with accurate visualization
- Interactive charts showing:
  - **Time-based attention drop-off curves** displaying engagement decay patterns
  - **Emotional response heatmaps** showing sentiment intensity over time
  - Cognitive load indicators throughout video timeline
  - Trust vs urgency balance visualization
- **Fixed Insights System**: "View Insights" button properly displays AI-generated behavioral summaries
- Performance indicators with "Kill / Improve / Scale" recommendations
- AI-generated optimization suggestions for hooks, CTAs, messaging, and audience targeting

### Comparative Analysis
- **Fixed Ranking System**: Proper backend integration for ad performance comparison
- Rank all ads within a project by performance with reliable data retrieval
- Identify top-performing ad as "Winner" with proper backend queries
- Provide explanations for performance differences based on behavioral modeling
- Highlight best-responding audience segments with demographic-specific insights

### Reporting and Export
- Generate comprehensive performance reports with complete backend integration
- Provide best ad recommendations with demographic breakdowns
- Include expected learning quality predictions
- Calculate risk assessments based on fatigue and trust factors
- Export capabilities for PDF, PPT, and CSV formats with proper file generation

## Data Storage Requirements

### Backend Data Persistence
- **Enhanced Authentication Endpoints**: Dedicated Internet Identity integration endpoints with session validation and retry support
- **Session Management API**: Backend endpoints for user session verification, initialization, and state persistence with timeout protection
- **Enhanced Backend Health Monitoring**: Dedicated health check endpoint responding within 500ms for frontend readiness verification
- **Bulletproof Project Operations**: Reliable createProject, getProject, getAllProjects endpoints with comprehensive error handling and retry logic
- **User Session Validation**: Backend endpoints to verify authenticated user state with timeout protection
- Project information (name, industry, creation date) with proper CRUD operations
- Ad creative metadata and file references with blob storage integration
- Audience configuration settings with validation and persistence
- Targeting parameters with proper data structure, including countries array supporting India
- **Fixed Simulation Storage**: Generated behavioral simulation results with complete data persistence
- Performance metrics and scores with proper calculation and storage
- Comparative analysis results with reliable ranking algorithms
- User-generated optimization notes with proper backend integration
- **Enhanced Session Management**: Robust user session handling with timeout protection and state verification
- **Connection Monitoring**: Backend health checks and connection status tracking with rapid response times

### File Storage
- Video creative files via blob storage with proper upload handling
- Generated report files with reliable file management
- Exported data files with proper format conversion

## Technical Requirements

### Authentication Integration
- **Internet Identity Backend Integration**: Complete backend support for Internet Identity authentication flow with session management
- **Authentication State API**: Backend endpoints for user authentication status verification and session persistence
- **Retry Logic Support**: Backend endpoints designed to handle authentication retry scenarios with exponential backoff support
- **Session Timeout Handling**: Backend session management with proper timeout and renewal mechanisms

### Backend Integration
- **Critical Backend Readiness API**: Mandatory health check endpoint for frontend verification within 500ms response time
- **Enhanced User Authentication API**: Reliable endpoint to verify user authentication status with timeout protection
- **Bulletproof API Endpoints**: Complete implementation of all backend calls with comprehensive error handling, retry logic, and health checks
- **Reliable Data Flow**: Seamless connection between frontend components and backend services with guaranteed state consistency
- **Robust Session Management**: Enhanced user session initialization and maintenance with automatic timeout protection
- **Comprehensive Error Recovery**: Advanced error handling for all backend operations with automatic retry mechanisms and exponential backoff
- **Optimized Loading States**: Fast-responding loading indicators for all asynchronous operations with 2-second maximum timeout and guaranteed state reset
- **Country Data Support**: Backend properly handles India in countries array for Ad objects

### Simulation System
- **Fixed simulation.ts Integration**: Complete connection between simulation functions and visualization components
- Advanced behavioral simulation algorithms with demographic modeling
- Sentiment analysis capabilities for emotional mapping
- **Reliable Metrics Pipeline**: Seamless data flow from simulation to dashboard rendering

### Frontend Architecture
- **Fixed Internet Identity Authentication**: Complete authentication flow integration with stable hooks, automatic retry logic, and session validation
- **Stable Authentication Hook**: Robust React hook for authentication state management with exponential backoff retry mechanism
- **Authentication Error Handling**: Clear error messaging and refresh prompts for persistent authentication failures
- **Guaranteed Post-Auth Navigation**: Direct navigation to appropriate screens after successful authentication with valid session context
- **Critical Get Started Button Repair**: Complete debugging and fixing of navigation workflow with guaranteed state reset and backend verification
- **Enhanced Navigation System**: Bulletproof React Router integration with advanced state management and automatic reset capabilities
- **Robust Component Integration**: Complete connection between all UI components and backend services with state consistency verification
- **Bulletproof Button Functionality**: All major UI buttons properly wired to handlers with timeout protection, retry mechanisms, and stuck-state prevention
- **Advanced State Management**: Robust React state management with automatic cleanup and reset mechanisms for all user interactions
- **Comprehensive Error Handling**: User-friendly error messages and recovery options with automatic state reset and retry functionality
- **Optimized Navigation Flow**: Complete click-through flow from landing → Get Started → Project Setup loading within 2 seconds with guaranteed success
- **State Reset Logic**: App.tsx navigation hook properly resets all state after operations to maintain navigation consistency
- **Country Selection UI**: AdCreativeForm component includes India in country dropdown with multi-select functionality
- **Complete Integration Testing**: Comprehensive frontend-backend integration tests covering all routes, buttons, and data flows

### Visualization System
- **Fixed Dashboard Components**: Complete integration of all visualization components with simulation data
- Chart and visualization libraries with proper data binding
- Real-time updates for metrics and performance indicators
- Interactive elements with proper event handling
- **Country Display**: AdsList and AnalyticsDashboard components properly display India in country lists

### Export and Reporting
- PDF/PPT generation capabilities with proper backend integration
- CSV export functionality with reliable data formatting
- File download handling with proper error management

## User Interface Requirements
- Application content language: English
- **Fixed Internet Identity Authentication Flow**: Complete authentication experience with automatic initialization, retry logic, and clear error messaging
- **Bulletproof Get Started Experience**: Complete workflow from landing page to project setup with guaranteed 2-second navigation and no stuck states
- **Reliable Interactions**: All buttons and UI elements properly connected to backend functionality with timeout protection and retry mechanisms
- **Optimized Loading Feedback**: Fast-responding loading states for all operations with automatic cleanup and guaranteed 2-second maximum duration
- **Clear Error Communication**: Comprehensive error messages and recovery guidance for users with automatic state reset and retry options
- **Guaranteed Success Confirmation**: Reliable feedback for successful operations and state changes with proper state management
- **Enhanced Country Selection**: India appears as selectable option in country dropdown with proper multi-select support

## Performance Requirements
- **Authentication Flow**: Maximum 3-second authentication initialization with automatic retry up to 3 times using exponential backoff
- **Get Started Navigation**: Maximum 2-second loading time from button click to Project Setup component display with guaranteed state reset
- **Backend Health Check**: Response time under 500ms for readiness verification with automatic retry on failure
- **State Reset Guarantee**: All navigation states properly reset after operations to prevent stuck states with comprehensive cleanup
- **Button Response Time**: All interactive elements respond within 200ms with proper feedback and timeout protection
- **Integration Test Coverage**: Complete test suite covering all critical user flows and backend integrations

## Compliance and Disclaimers
- Display prominent disclaimer: "All outputs are behavioral simulations. No access to Meta's internal algorithms."
- Focus on ethical simulation practices
- Ensure predictive modeling transparency
