import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { ProjectView, Ad, Industry, BehavioralMetrics, BehavioralInsights } from '../backend';
import { toast } from 'sonner';

export function useGetProject() {
  const { actor, isFetching } = useActor();

  return useQuery<ProjectView | null>({
    queryKey: ['project'],
    queryFn: async () => {
      if (!actor) {
        throw new Error('Backend actor not initialized');
      }
      try {
        const project = await actor.getProject();
        return project;
      } catch (error) {
        // Project doesn't exist yet, return null instead of throwing
        if (error instanceof Error && error.message.includes('does not exist')) {
          return null;
        }
        // Not authenticated error
        if (error instanceof Error && error.message.includes('Not authenticated')) {
          throw new Error('Session not initialized. Please try again.');
        }
        throw error;
      }
    },
    enabled: !!actor && !isFetching,
    retry: (failureCount, error) => {
      // Don't retry if project doesn't exist
      if (error instanceof Error && error.message.includes('does not exist')) {
        return false;
      }
      // Don't retry if not authenticated (session issue)
      if (error instanceof Error && error.message.includes('Not authenticated')) {
        return false;
      }
      // Retry up to 3 times for other errors
      return failureCount < 3;
    },
    retryDelay: (attemptIndex) => Math.min(300 * Math.pow(2, attemptIndex), 3000),
    staleTime: 1000,
    refetchOnMount: true,
  });
}

export function useInitializeSession() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not initialized');
      await actor.initializeSession();
    },
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(300 * Math.pow(2, attemptIndex), 3000),
    onError: (error: Error) => {
      console.error('Session initialization failed:', error);
    },
  });
}

export function useIsAuthenticated() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isAuthenticated'],
    queryFn: async () => {
      if (!actor) return false;
      try {
        return await actor.isAuthenticated();
      } catch (error) {
        console.error('Failed to check authentication status:', error);
        return false;
      }
    },
    enabled: !!actor && !isFetching,
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(300 * Math.pow(2, attemptIndex), 3000),
    staleTime: 5000,
  });
}

export function useCreateProject() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, name, industry }: { id: string; name: string; industry: Industry }) => {
      if (!actor) throw new Error('Actor not initialized');
      await actor.createProject(id, name, industry);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project'] });
      toast.success('Project created successfully');
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to create project');
    },
  });
}

export function useAddAd() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ projectId, ad }: { projectId: string; ad: Ad }) => {
      if (!actor) throw new Error('Actor not initialized');
      await actor.addAd(projectId, ad);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project'] });
      toast.success('Ad added successfully');
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to add ad');
    },
  });
}

export function useEvaluatePerformance() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async ({ projectId, adId }: { projectId: string; adId: string }) => {
      if (!actor) throw new Error('Actor not initialized');
      return await actor.evaluatePerformance(projectId, adId);
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to evaluate performance');
    },
  });
}

export function useGenerateAgeBreakdown() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async ({ projectId, adId }: { projectId: string; adId: string }) => {
      if (!actor) throw new Error('Actor not initialized');
      return await actor.generateAgeBreakdown(projectId, adId);
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to generate insights');
    },
  });
}

export function useRateAdContent() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async ({ projectId, adId, metric }: { projectId: string; adId: string; metric: string }) => {
      if (!actor) throw new Error('Actor not initialized');
      return await actor.rateAdContent(projectId, adId, metric);
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to rate ad content');
    },
  });
}
