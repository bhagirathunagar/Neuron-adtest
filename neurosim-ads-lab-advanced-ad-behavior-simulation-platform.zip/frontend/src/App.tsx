import { useState, useEffect, useRef } from 'react';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetProject, useInitializeSession } from './hooks/useQueries';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ProjectSetup } from './components/ProjectSetup';
import { Dashboard } from './components/Dashboard';
import { Toaster } from './components/ui/sonner';
import { ThemeProvider } from 'next-themes';
import { Loader2, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

export default function App() {
  const { identity, login, loginStatus, isInitializing, loginError } = useInternetIdentity();
  const { mutateAsync: initializeSession } = useInitializeSession();
  const { data: project, isLoading: projectLoading, error: projectError, refetch } = useGetProject();
  const [showSetup, setShowSetup] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);
  const [authRetryCount, setAuthRetryCount] = useState(0);
  const [sessionInitialized, setSessionInitialized] = useState(false);
  const [persistentError, setPersistentError] = useState<string | null>(null);
  const navigationTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const MAX_AUTH_RETRIES = 3;

  const isAuthenticated = !!identity && loginStatus === 'success';
  const hasProject = project !== null && project !== undefined;

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (navigationTimeoutRef.current) {
        clearTimeout(navigationTimeoutRef.current);
      }
    };
  }, []);

  // Handle authentication retry logic with exponential backoff
  useEffect(() => {
    if (loginStatus === 'loginError' && authRetryCount < MAX_AUTH_RETRIES && isNavigating) {
      const retryDelay = 500 * Math.pow(2, authRetryCount);
      console.log(`Authentication failed, retrying in ${retryDelay}ms (attempt ${authRetryCount + 1}/${MAX_AUTH_RETRIES})`);
      
      const retryTimeout = setTimeout(() => {
        setAuthRetryCount(prev => prev + 1);
        login();
      }, retryDelay);

      return () => clearTimeout(retryTimeout);
    } else if (loginStatus === 'loginError' && authRetryCount >= MAX_AUTH_RETRIES && isNavigating) {
      // All retries exhausted
      console.error('Authentication failed after all retries');
      setPersistentError('Authentication failed after multiple attempts. Please refresh the page and try again.');
      setIsNavigating(false);
      setAuthRetryCount(0);
      
      if (navigationTimeoutRef.current) {
        clearTimeout(navigationTimeoutRef.current);
        navigationTimeoutRef.current = null;
      }
    }
  }, [loginStatus, authRetryCount, isNavigating, login]);

  // Initialize session after successful authentication
  useEffect(() => {
    if (isAuthenticated && !sessionInitialized && isNavigating) {
      const initSession = async () => {
        try {
          console.log('Initializing backend session...');
          await initializeSession();
          setSessionInitialized(true);
          console.log('Backend session initialized successfully');
        } catch (error) {
          console.error('Failed to initialize session:', error);
          // Retry session initialization
          if (authRetryCount < MAX_AUTH_RETRIES) {
            const retryDelay = 300 * Math.pow(2, authRetryCount);
            setTimeout(() => {
              setAuthRetryCount(prev => prev + 1);
            }, retryDelay);
          } else {
            setPersistentError('Failed to initialize session. Please refresh the page and try again.');
            setIsNavigating(false);
            setAuthRetryCount(0);
            
            if (navigationTimeoutRef.current) {
              clearTimeout(navigationTimeoutRef.current);
              navigationTimeoutRef.current = null;
            }
          }
        }
      };

      initSession();
    }
  }, [isAuthenticated, sessionInitialized, isNavigating, initializeSession, authRetryCount]);

  // Handle navigation after session initialization
  useEffect(() => {
    if (isAuthenticated && sessionInitialized && isNavigating) {
      const completeNavigation = async () => {
        try {
          console.log('Loading project data...');
          
          // Attempt to fetch project with retry logic
          let fetchSuccess = false;
          let retries = 0;
          
          while (!fetchSuccess && retries < MAX_AUTH_RETRIES) {
            try {
              await refetch();
              fetchSuccess = true;
              console.log('Project data loaded successfully');
            } catch (error) {
              retries++;
              if (retries < MAX_AUTH_RETRIES) {
                const retryDelay = 300 * Math.pow(2, retries - 1);
                console.log(`Project fetch failed, retrying in ${retryDelay}ms (attempt ${retries}/${MAX_AUTH_RETRIES})`);
                await new Promise(resolve => setTimeout(resolve, retryDelay));
              } else {
                throw error;
              }
            }
          }

          // Clear timeout and complete navigation
          if (navigationTimeoutRef.current) {
            clearTimeout(navigationTimeoutRef.current);
            navigationTimeoutRef.current = null;
          }

          setIsNavigating(false);
          setAuthRetryCount(0);
          setPersistentError(null);
        } catch (error) {
          console.error('Backend connection failed:', error);
          
          // Clear timeout
          if (navigationTimeoutRef.current) {
            clearTimeout(navigationTimeoutRef.current);
            navigationTimeoutRef.current = null;
          }

          setPersistentError('Failed to connect to backend. Please refresh the page and try again.');
          setIsNavigating(false);
          setAuthRetryCount(0);
        }
      };

      completeNavigation();
    }
  }, [isAuthenticated, sessionInitialized, isNavigating, refetch]);

  const handleGetStarted = () => {
    // Prevent multiple clicks
    if (isNavigating || loginStatus === 'logging-in') {
      return;
    }

    // Reset states
    setIsNavigating(true);
    setAuthRetryCount(0);
    setSessionInitialized(false);
    setPersistentError(null);

    // Set 3-second timeout protection for authentication
    navigationTimeoutRef.current = setTimeout(() => {
      console.warn('Authentication timeout - forcing state reset');
      setPersistentError('Authentication took too long. Please refresh the page and try again.');
      setIsNavigating(false);
      setAuthRetryCount(0);
      setSessionInitialized(false);
    }, 3000);

    // Initiate login
    login();
  };

  const handleRefresh = () => {
    window.location.reload();
  };

  // Show initial loading state
  if (isInitializing) {
    return (
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center space-y-4">
            <Loader2 className="w-12 h-12 animate-spin mx-auto text-purple-500" />
            <p className="text-muted-foreground">Initializing authentication...</p>
          </div>
        </div>
      </ThemeProvider>
    );
  }

  // Show persistent error state
  if (persistentError) {
    return (
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center space-y-6 max-w-md mx-auto px-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-destructive/10 flex items-center justify-center">
              <span className="text-3xl">⚠️</span>
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-semibold text-foreground">Authentication Error</h2>
              <p className="text-sm text-muted-foreground">{persistentError}</p>
            </div>
            <button
              onClick={handleRefresh}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-2 mx-auto"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh Page
            </button>
          </div>
        </div>
      </ThemeProvider>
    );
  }

  // Determine if we're in a loading state
  const isLoadingWorkspace = isNavigating || (isAuthenticated && projectLoading);

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1">
          {!isAuthenticated ? (
            <div className="container mx-auto px-4 py-16">
              <div className="max-w-4xl mx-auto text-center space-y-8">
                <div className="space-y-4">
                  <img 
                    src="/assets/generated/neuro-brain-ai.dim_400x400.png" 
                    alt="NeuroSim AI"
                    className="w-32 h-32 mx-auto rounded-2xl shadow-2xl"
                  />
                  <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                    NeuroSim Ads Lab
                  </h1>
                  <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                    Advanced simulation and prediction platform that models human ad behavior for Facebook and Instagram ads
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-6 mt-12">
                  <div className="p-6 rounded-xl bg-card border border-border">
                    <div className="text-3xl mb-3">🧠</div>
                    <h3 className="font-semibold mb-2">Neural Behavior Engine</h3>
                    <p className="text-sm text-muted-foreground">
                      Simulates realistic human responses across attention, emotion, and intent
                    </p>
                  </div>
                  <div className="p-6 rounded-xl bg-card border border-border">
                    <div className="text-3xl mb-3">📊</div>
                    <h3 className="font-semibold mb-2">Advanced Metrics</h3>
                    <p className="text-sm text-muted-foreground">
                      Hook strength, cognitive load, emotional resonance, and more
                    </p>
                  </div>
                  <div className="p-6 rounded-xl bg-card border border-border">
                    <div className="text-3xl mb-3">🎯</div>
                    <h3 className="font-semibold mb-2">Predictive Intelligence</h3>
                    <p className="text-sm text-muted-foreground">
                      AI-powered recommendations for optimization and scaling
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleGetStarted}
                  disabled={isNavigating || loginStatus === 'logging-in'}
                  className="mt-8 px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-xl shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-95 flex items-center gap-2 mx-auto"
                >
                  {isNavigating || loginStatus === 'logging-in' ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      {authRetryCount > 0 
                        ? `Retrying authentication (${authRetryCount}/${MAX_AUTH_RETRIES})...`
                        : sessionInitialized 
                          ? 'Loading workspace...' 
                          : 'Connecting...'}
                    </>
                  ) : (
                    'Get Started'
                  )}
                </button>

                <div className="mt-8 p-4 bg-muted/50 rounded-lg border border-border max-w-2xl mx-auto">
                  <p className="text-xs text-muted-foreground">
                    ⚠️ <strong>Disclaimer:</strong> All outputs are behavioral simulations. No access to Meta's internal algorithms.
                  </p>
                </div>
              </div>
            </div>
          ) : isLoadingWorkspace ? (
            <div className="container mx-auto px-4 py-16 text-center">
              <div className="space-y-4">
                <Loader2 className="w-12 h-12 animate-spin mx-auto text-purple-500" />
                <p className="text-muted-foreground">
                  {sessionInitialized ? 'Preparing your workspace...' : 'Initializing session...'}
                </p>
              </div>
            </div>
          ) : !hasProject || showSetup ? (
            <ProjectSetup onComplete={() => setShowSetup(false)} />
          ) : (
            <Dashboard project={project} onAddNew={() => setShowSetup(true)} />
          )}
        </main>

        <Footer />
        <Toaster />
      </div>
    </ThemeProvider>
  );
}
