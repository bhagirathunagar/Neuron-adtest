import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface EmotionalHeatmapProps {
  data: Array<{ time: number; emotion: number; type: string }>;
}

const EMOTION_COLORS = {
  excitement: 'hsl(var(--chart-1))',
  interest: 'hsl(var(--chart-2))',
  trust: 'hsl(var(--chart-3))',
  action: 'hsl(var(--chart-4))',
};

export function EmotionalHeatmap({ data }: EmotionalHeatmapProps) {
  return (
    <ResponsiveContainer width="100%" height={250}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
        <XAxis 
          dataKey="time" 
          className="text-xs"
          label={{ value: 'Time (seconds)', position: 'insideBottom', offset: -5, className: 'text-xs' }}
        />
        <YAxis 
          className="text-xs"
          label={{ value: 'Emotional Intensity %', angle: -90, position: 'insideLeft', className: 'text-xs' }}
          domain={[0, 100]}
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '0.5rem'
          }}
          formatter={(value: number, name: string, props: any) => [
            `${value}%`,
            `${props.payload.type.charAt(0).toUpperCase() + props.payload.type.slice(1)}`
          ]}
          labelFormatter={(label) => `${label}s`}
        />
        <Bar dataKey="emotion" radius={[4, 4, 0, 0]}>
          {data.map((entry, index) => (
            <Cell 
              key={`cell-${index}`} 
              fill={EMOTION_COLORS[entry.type as keyof typeof EMOTION_COLORS] || 'hsl(var(--primary))'}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
