import { useMemo } from 'react';
import type { Ad } from '../backend';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, 
  Brain, Eye, Heart, Zap, Target, MessageSquare, Users, Activity
} from 'lucide-react';
import { PerformanceChart } from './PerformanceChart';
import { MetricsGauge } from './MetricsGauge';
import { AttentionDecayChart } from './AttentionDecayChart';
import { EmotionalHeatmap } from './EmotionalHeatmap';
import { simulateAdMetrics, type AdMetrics } from '../lib/simulation';

interface AnalyticsDashboardProps {
  ads: Ad[];
}

export function AnalyticsDashboard({ ads }: AnalyticsDashboardProps) {
  const adsWithMetrics = useMemo(() => {
    return ads.map(ad => ({
      ad,
      metrics: simulateAdMetrics(ad)
    })).sort((a, b) => b.metrics.overallScore - a.metrics.overallScore);
  }, [ads]);

  const winner = adsWithMetrics[0];

  if (ads.length === 0) {
    return (
      <div className="text-center py-12">
        <Brain className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
        <p className="text-muted-foreground">Add ads to see behavioral analytics</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Winner Card */}
      {winner && (
        <Card className="border-2 border-primary bg-gradient-to-br from-primary/5 to-transparent">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6 text-primary" />
                  Top Performer
                </CardTitle>
                <CardDescription>Highest predicted performance with advanced neuro-metrics</CardDescription>
              </div>
              <Badge className="text-lg px-4 py-2">
                {winner.metrics.overallScore}% Score
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-2">{winner.ad.headline}</h3>
                <p className="text-sm text-muted-foreground mb-4">{winner.ad.primaryText}</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{winner.ad.cta}</Badge>
                  <Badge variant="outline">{winner.ad.conversionGoal}</Badge>
                  {winner.ad.targetAgeGroups.length > 0 && <Badge variant="outline">{winner.ad.targetAgeGroups.join(', ')}</Badge>}
                  {winner.ad.targetGenders.length > 0 && <Badge variant="outline">{winner.ad.targetGenders.join(', ')}</Badge>}
                </div>
              </div>
              <div className="space-y-3">
                <MetricBar 
                  label="Hook Strength" 
                  value={winner.metrics.hookStrength} 
                  icon={<Zap className="w-4 h-4" />}
                />
                <MetricBar 
                  label="Emotional Resonance" 
                  value={winner.metrics.emotionalResonance} 
                  icon={<Heart className="w-4 h-4" />}
                />
                <MetricBar 
                  label="Scroll-Stop Probability" 
                  value={winner.metrics.scrollStopProbability} 
                  icon={<Eye className="w-4 h-4" />}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Comparative Analysis */}
      <div className="grid lg:grid-cols-3 gap-6">
        {adsWithMetrics.map(({ ad, metrics }, index) => (
          <Card key={ad.id} className={index === 0 ? 'border-primary' : ''}>
            <CardHeader>
              <div className="flex items-center justify-between mb-2">
                <CardTitle className="text-lg line-clamp-1">{ad.headline}</CardTitle>
                {index === 0 && <Badge variant="default">Winner</Badge>}
              </div>
              <div className="flex items-center gap-2">
                <div className="text-3xl font-bold">{metrics.overallScore}%</div>
                <div className="text-sm text-muted-foreground">Overall Score</div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Attention Rate</span>
                  <span className="font-medium">{metrics.attentionRate}%</span>
                </div>
                <Progress value={metrics.attentionRate} />
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="space-y-1">
                  <div className="text-muted-foreground">Hook</div>
                  <div className="font-semibold">{metrics.hookStrength}%</div>
                </div>
                <div className="space-y-1">
                  <div className="text-muted-foreground">Hold Rate</div>
                  <div className="font-semibold">{metrics.holdRate}%</div>
                </div>
                <div className="space-y-1">
                  <div className="text-muted-foreground">Trust</div>
                  <div className="font-semibold">{metrics.trustLevel}%</div>
                </div>
                <div className="space-y-1">
                  <div className="text-muted-foreground">Intent</div>
                  <div className="font-semibold">{metrics.outboundIntentProbability}%</div>
                </div>
              </div>

              <div className="pt-3 border-t">
                <RecommendationBadge recommendation={metrics.recommendation} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed Metrics */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="behavioral">Behavioral Insights</TabsTrigger>
          <TabsTrigger value="neuro">Neuro-Metrics</TabsTrigger>
          <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Comparison</CardTitle>
                <CardDescription>Overall scores across all ads</CardDescription>
              </CardHeader>
              <CardContent>
                <PerformanceChart data={adsWithMetrics} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Metrics Distribution</CardTitle>
                <CardDescription>Top performer behavioral profile</CardDescription>
              </CardHeader>
              <CardContent>
                <MetricsGauge metrics={winner?.metrics} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="behavioral" className="space-y-6">
          {adsWithMetrics.map(({ ad, metrics }) => (
            <Card key={ad.id}>
              <CardHeader>
                <CardTitle>{ad.headline}</CardTitle>
                <CardDescription>Deep behavioral simulation results</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Brain className="w-4 h-4" />
                      Cognitive Analysis
                    </h4>
                    <MetricItem label="Cognitive Load" value={metrics.cognitiveLoad} />
                    <MetricItem label="Clarity Score" value={100 - metrics.cognitiveLoad} />
                    <MetricItem label="Processing Ease" value={metrics.holdRate} />
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Heart className="w-4 h-4" />
                      Emotional Response
                    </h4>
                    <MetricItem label="Emotional Resonance" value={metrics.emotionalResonance} />
                    <MetricItem label="Trust Level" value={metrics.trustLevel} />
                    <MetricItem label="Fatigue Risk" value={metrics.fatigueRisk} inverse />
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Target className="w-4 h-4" />
                      Action Probability
                    </h4>
                    <MetricItem label="Scroll-Stop" value={metrics.scrollStopProbability} />
                    <MetricItem label="Outbound Intent" value={metrics.outboundIntentProbability} />
                    <MetricItem label="Conversion Likelihood" value={metrics.conversionLikelihood} />
                  </div>
                </div>

                {/* Demographic Insights */}
                {metrics.demographicInsights.length > 0 && (
                  <div className="mt-6 pt-6 border-t">
                    <h4 className="font-semibold flex items-center gap-2 mb-3">
                      <Users className="w-4 h-4" />
                      AI Demographic Insights
                    </h4>
                    <div className="space-y-2">
                      {metrics.demographicInsights.map((insight, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-sm bg-muted/50 p-3 rounded-lg">
                          <Activity className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />
                          <span>{insight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="neuro" className="space-y-6">
          {adsWithMetrics.map(({ ad, metrics }) => (
            <Card key={ad.id}>
              <CardHeader>
                <CardTitle>{ad.headline}</CardTitle>
                <CardDescription>Andromeda-style neuro-behavioral analysis</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Attention Decay Curve */}
                <div>
                  <h4 className="font-semibold flex items-center gap-2 mb-4">
                    <Eye className="w-4 h-4" />
                    Attention Drop-Off Timeline
                  </h4>
                  <AttentionDecayChart data={metrics.attentionDecayCurve} />
                  <p className="text-sm text-muted-foreground mt-2">
                    Shows exponential attention decay based on age group ({ad.targetAgeGroups[0] || '25-34'}) and creative engagement strength.
                  </p>
                </div>

                {/* Emotional Heatmap */}
                <div className="pt-6 border-t">
                  <h4 className="font-semibold flex items-center gap-2 mb-4">
                    <Heart className="w-4 h-4" />
                    Emotional Response Heatmap
                  </h4>
                  <EmotionalHeatmap data={metrics.emotionalHeatmap} />
                  <p className="text-sm text-muted-foreground mt-2">
                    Emotional intensity mapped across video timeline, showing hook phase, engagement phase, and CTA response.
                  </p>
                </div>

                {/* Neuro-Metrics Summary */}
                <div className="pt-6 border-t">
                  <h4 className="font-semibold mb-4">Neuro-Metrics Summary</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Hook Strength</span>
                        <span className="font-semibold">{metrics.hookStrength}%</span>
                      </div>
                      <Progress value={metrics.hookStrength} />
                      <p className="text-xs text-muted-foreground">Initial attention capture effectiveness</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Hold Rate</span>
                        <span className="font-semibold">{metrics.holdRate}%</span>
                      </div>
                      <Progress value={metrics.holdRate} />
                      <p className="text-xs text-muted-foreground">Sustained attention throughout creative</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Cognitive Load</span>
                        <span className="font-semibold">{metrics.cognitiveLoad}%</span>
                      </div>
                      <Progress value={metrics.cognitiveLoad} />
                      <p className="text-xs text-muted-foreground">Mental processing difficulty (lower is better)</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Emotional Resonance</span>
                        <span className="font-semibold">{metrics.emotionalResonance}%</span>
                      </div>
                      <Progress value={metrics.emotionalResonance} />
                      <p className="text-xs text-muted-foreground">Emotional connection strength</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Trust Level</span>
                        <span className="font-semibold">{metrics.trustLevel}%</span>
                      </div>
                      <Progress value={metrics.trustLevel} />
                      <p className="text-xs text-muted-foreground">Credibility and trustworthiness perception</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fatigue Risk</span>
                        <span className="font-semibold">{metrics.fatigueRisk}%</span>
                      </div>
                      <Progress value={metrics.fatigueRisk} />
                      <p className="text-xs text-muted-foreground">Audience saturation likelihood (lower is better)</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Scroll-Stop Probability</span>
                        <span className="font-semibold">{metrics.scrollStopProbability}%</span>
                      </div>
                      <Progress value={metrics.scrollStopProbability} />
                      <p className="text-xs text-muted-foreground">Likelihood to pause scrolling</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Outbound Intent Probability</span>
                        <span className="font-semibold">{metrics.outboundIntentProbability}%</span>
                      </div>
                      <Progress value={metrics.outboundIntentProbability} />
                      <p className="text-xs text-muted-foreground">Conversion action likelihood</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          {adsWithMetrics.map(({ ad, metrics }) => (
            <Card key={ad.id}>
              <CardHeader>
                <CardTitle>{ad.headline}</CardTitle>
                <CardDescription>AI-powered optimization suggestions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                  <RecommendationIcon recommendation={metrics.recommendation} />
                  <div>
                    <div className="font-semibold">
                      {metrics.recommendation === 'scale' && 'Scale This Ad'}
                      {metrics.recommendation === 'improve' && 'Needs Improvement'}
                      {metrics.recommendation === 'kill' && 'Consider Replacing'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {metrics.recommendation === 'scale' && 'Strong performance across all neuro-metrics'}
                      {metrics.recommendation === 'improve' && 'Moderate performance with optimization potential'}
                      {metrics.recommendation === 'kill' && 'Low performance indicators across key metrics'}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">Optimization Suggestions:</h4>
                  <ul className="space-y-2">
                    {metrics.hookStrength < 70 && (
                      <li className="flex items-start gap-2 text-sm">
                        <MessageSquare className="w-4 h-4 mt-0.5 text-primary" />
                        <span><strong>Hook:</strong> Start with a stronger attention-grabber. Consider using a question, surprising statement, or pattern interrupt.</span>
                      </li>
                    )}
                    {metrics.cognitiveLoad > 60 && (
                      <li className="flex items-start gap-2 text-sm">
                        <Brain className="w-4 h-4 mt-0.5 text-primary" />
                        <span><strong>Clarity:</strong> Simplify your message. Reduce cognitive load by focusing on one key benefit and using shorter sentences.</span>
                      </li>
                    )}
                    {metrics.emotionalResonance < 65 && (
                      <li className="flex items-start gap-2 text-sm">
                        <Heart className="w-4 h-4 mt-0.5 text-primary" />
                        <span><strong>Emotion:</strong> Add more emotional appeal. Use storytelling, relatable scenarios, or aspirational imagery.</span>
                      </li>
                    )}
                    {metrics.trustLevel < 70 && (
                      <li className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 text-primary" />
                        <span><strong>Trust:</strong> Include social proof, testimonials, certifications, or credibility indicators to build confidence.</span>
                      </li>
                    )}
                    {metrics.outboundIntentProbability < 60 && (
                      <li className="flex items-start gap-2 text-sm">
                        <Target className="w-4 h-4 mt-0.5 text-primary" />
                        <span><strong>CTA:</strong> Make your call-to-action more compelling and urgent. Add time-sensitive language or clear value proposition.</span>
                      </li>
                    )}
                    {metrics.fatigueRisk > 60 && (
                      <li className="flex items-start gap-2 text-sm">
                        <AlertTriangle className="w-4 h-4 mt-0.5 text-primary" />
                        <span><strong>Fatigue:</strong> High fatigue risk detected. Consider shortening the video or simplifying the message to maintain engagement.</span>
                      </li>
                    )}
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    <strong>Expected Meta Learning Quality:</strong> {metrics.overallScore >= 80 ? 'High' : metrics.overallScore >= 60 ? 'Medium' : 'Low'}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    <strong>Risk Score:</strong> {metrics.fatigueRisk >= 70 ? 'High' : metrics.fatigueRisk >= 40 ? 'Medium' : 'Low'}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      {/* Disclaimer */}
      <Card className="bg-muted/50">
        <CardContent className="py-4">
          <p className="text-sm text-muted-foreground text-center">
            ⚠️ <strong>Disclaimer:</strong> All outputs are behavioral simulations based on predictive models and demographic psychology. 
            No access to Meta's internal algorithms. Results are estimates for planning purposes.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function MetricBar({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-sm">
        <span className="flex items-center gap-2 text-muted-foreground">
          {icon}
          {label}
        </span>
        <span className="font-semibold">{value}%</span>
      </div>
      <Progress value={value} />
    </div>
  );
}

function MetricItem({ label, value, inverse }: { label: string; value: number; inverse?: boolean }) {
  const displayValue = inverse ? 100 - value : value;
  const color = displayValue >= 70 ? 'text-green-600' : displayValue >= 50 ? 'text-yellow-600' : 'text-red-600';
  
  return (
    <div className="flex justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-semibold ${color}`}>{displayValue}%</span>
    </div>
  );
}

function RecommendationBadge({ recommendation }: { recommendation: 'scale' | 'improve' | 'kill' }) {
  if (recommendation === 'scale') {
    return (
      <Badge className="w-full justify-center bg-green-600 hover:bg-green-700">
        <TrendingUp className="w-3 h-3 mr-1" />
        Scale
      </Badge>
    );
  }
  if (recommendation === 'improve') {
    return (
      <Badge variant="secondary" className="w-full justify-center">
        <AlertTriangle className="w-3 h-3 mr-1" />
        Improve
      </Badge>
    );
  }
  return (
    <Badge variant="destructive" className="w-full justify-center">
      <TrendingDown className="w-3 h-3 mr-1" />
      Kill
    </Badge>
  );
}

function RecommendationIcon({ recommendation }: { recommendation: 'scale' | 'improve' | 'kill' }) {
  if (recommendation === 'scale') {
    return <TrendingUp className="w-8 h-8 text-green-600" />;
  }
  if (recommendation === 'improve') {
    return <AlertTriangle className="w-8 h-8 text-yellow-600" />;
  }
  return <TrendingDown className="w-8 h-8 text-red-600" />;
}

