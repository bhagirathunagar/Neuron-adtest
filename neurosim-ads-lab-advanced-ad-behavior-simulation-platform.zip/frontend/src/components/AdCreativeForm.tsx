import { useState } from 'react';
import { useAddAd } from '../hooks/useQueries';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { Loader2, Upload, X } from 'lucide-react';
import { ExternalBlob } from '../backend';
import { toast } from 'sonner';

interface AdCreativeFormProps {
  projectId: string;
  onComplete: () => void;
  onCancel: () => void;
}

const ctaOptions = [
  'Learn More', 'Shop Now', 'Sign Up', 'Download', 'Get Quote', 
  'Contact Us', 'Book Now', 'Apply Now', 'Subscribe', 'Watch More'
];

const conversionLocations = ['WhatsApp', 'Website', 'Instagram DM', 'Lead Form'];
const conversionGoals = ['Messages', 'Leads', 'Purchases', 'Traffic', 'Awareness'];
const ageGroups = ['18-24', '25-34', '35-44', '45-54', '55+'];
const genders = ['Male', 'Female', 'All'];
const countries = ['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'France', 'Spain', 'Italy', 'Brazil', 'Mexico', 'India'];

export function AdCreativeForm({ projectId, onComplete, onCancel }: AdCreativeFormProps) {
  const [primaryText, setPrimaryText] = useState('');
  const [headline, setHeadline] = useState('');
  const [cta, setCta] = useState('');
  const [conversionLocation, setConversionLocation] = useState('');
  const [conversionGoal, setConversionGoal] = useState('');
  const [selectedAgeGroups, setSelectedAgeGroups] = useState<string[]>([]);
  const [selectedGenders, setSelectedGenders] = useState<string[]>([]);
  const [interests, setInterests] = useState('');
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [audienceSize, setAudienceSize] = useState('10000');
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const addAd = useAddAd();

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('video/')) {
        setVideoFile(file);
      } else {
        toast.error('Please select a valid video file');
      }
    }
  };

  const toggleAgeGroup = (age: string) => {
    setSelectedAgeGroups(prev => 
      prev.includes(age) ? prev.filter(a => a !== age) : [...prev, age]
    );
  };

  const toggleGender = (gender: string) => {
    setSelectedGenders(prev => 
      prev.includes(gender) ? prev.filter(g => g !== gender) : [...prev, gender]
    );
  };

  const toggleCountry = (country: string) => {
    setSelectedCountries(prev => 
      prev.includes(country) ? prev.filter(c => c !== country) : [...prev, country]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!videoFile) {
      toast.error('Please upload a video creative');
      return;
    }

    if (selectedAgeGroups.length === 0) {
      toast.error('Please select at least one age group');
      return;
    }

    if (selectedGenders.length === 0) {
      toast.error('Please select at least one gender');
      return;
    }

    if (selectedCountries.length === 0) {
      toast.error('Please select at least one country');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const arrayBuffer = await videoFile.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      
      const videoBlob = ExternalBlob.fromBytes(uint8Array).withUploadProgress((percentage) => {
        setUploadProgress(percentage);
      });

      const interestsList = interests.split(',').map(i => i.trim()).filter(i => i.length > 0);

      await addAd.mutateAsync({
        projectId,
        ad: {
          id: Date.now().toString(),
          videoCreative: videoBlob,
          primaryText,
          headline,
          cta,
          conversionLocation,
          conversionGoal,
          targetAgeGroups: selectedAgeGroups,
          targetGenders: selectedGenders,
          interests: interestsList,
          countries: selectedCountries,
          audienceSize: BigInt(parseInt(audienceSize)),
        },
      });

      onComplete();
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload ad creative');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <Card className="max-w-5xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl">Add New Ad Creative</CardTitle>
            <CardDescription>Upload your ad and configure targeting parameters</CardDescription>
          </div>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-5 h-5" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="video">Video Creative *</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
                  <input
                    type="file"
                    id="video"
                    accept="video/*"
                    onChange={handleVideoChange}
                    className="hidden"
                  />
                  <label htmlFor="video" className="cursor-pointer">
                    {videoFile ? (
                      <div className="space-y-2">
                        <div className="text-sm font-medium">{videoFile.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {(videoFile.size / 1024 / 1024).toFixed(2)} MB
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
                        <div className="text-sm text-muted-foreground">
                          Click to upload video
                        </div>
                      </div>
                    )}
                  </label>
                </div>
                {isUploading && uploadProgress > 0 && (
                  <div className="space-y-1">
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all duration-300"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                    <div className="text-xs text-muted-foreground text-center">
                      Uploading: {uploadProgress}%
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="primaryText">Primary Text *</Label>
                <Textarea
                  id="primaryText"
                  placeholder="Write compelling ad copy..."
                  value={primaryText}
                  onChange={(e) => setPrimaryText(e.target.value)}
                  rows={4}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="headline">Headline *</Label>
                <Input
                  id="headline"
                  placeholder="Attention-grabbing headline"
                  value={headline}
                  onChange={(e) => setHeadline(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cta">Call to Action *</Label>
                <Select value={cta} onValueChange={setCta} required>
                  <SelectTrigger id="cta">
                    <SelectValue placeholder="Select CTA" />
                  </SelectTrigger>
                  <SelectContent>
                    {ctaOptions.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="conversionLocation">Conversion Location *</Label>
                <Select value={conversionLocation} onValueChange={setConversionLocation} required>
                  <SelectTrigger id="conversionLocation">
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    {conversionLocations.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="conversionGoal">Conversion Goal *</Label>
                <Select value={conversionGoal} onValueChange={setConversionGoal} required>
                  <SelectTrigger id="conversionGoal">
                    <SelectValue placeholder="Select goal" />
                  </SelectTrigger>
                  <SelectContent>
                    {conversionGoals.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <Label>Target Age Groups *</Label>
                <div className="space-y-2 border rounded-lg p-4">
                  {ageGroups.map((age) => (
                    <div key={age} className="flex items-center space-x-2">
                      <Checkbox
                        id={`age-${age}`}
                        checked={selectedAgeGroups.includes(age)}
                        onCheckedChange={() => toggleAgeGroup(age)}
                      />
                      <label
                        htmlFor={`age-${age}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {age}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Target Genders *</Label>
                <div className="space-y-2 border rounded-lg p-4">
                  {genders.map((gender) => (
                    <div key={gender} className="flex items-center space-x-2">
                      <Checkbox
                        id={`gender-${gender}`}
                        checked={selectedGenders.includes(gender)}
                        onCheckedChange={() => toggleGender(gender)}
                      />
                      <label
                        htmlFor={`gender-${gender}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {gender}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="interests">Interests & Behaviors</Label>
                <Input
                  id="interests"
                  placeholder="e.g., Fashion, Technology, Fitness (comma-separated)"
                  value={interests}
                  onChange={(e) => setInterests(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Target Countries * (select at least one)</Label>
                <div className="space-y-2 border rounded-lg p-4 max-h-48 overflow-y-auto">
                  {countries.map((country) => (
                    <div key={country} className="flex items-center space-x-2">
                      <Checkbox
                        id={`country-${country}`}
                        checked={selectedCountries.includes(country)}
                        onCheckedChange={() => toggleCountry(country)}
                      />
                      <label
                        htmlFor={`country-${country}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {country}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="audienceSize">Audience Size</Label>
                <Input
                  id="audienceSize"
                  type="number"
                  min="1000"
                  max="100000"
                  step="1000"
                  value={audienceSize}
                  onChange={(e) => setAudienceSize(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Range: 1,000 - 100,000
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1"
              disabled={addAd.isPending || isUploading || !videoFile}
            >
              {addAd.isPending || isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {isUploading ? 'Uploading...' : 'Adding Ad...'}
                </>
              ) : (
                'Add Ad Creative'
              )}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
