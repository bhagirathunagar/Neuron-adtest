import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface AttentionDecayChartProps {
  data: Array<{ time: number; attention: number }>;
}

export function AttentionDecayChart({ data }: AttentionDecayChartProps) {
  return (
    <ResponsiveContainer width="100%" height={250}>
      <AreaChart data={data}>
        <defs>
          <linearGradient id="attentionGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.1}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
        <XAxis 
          dataKey="time" 
          className="text-xs"
          label={{ value: 'Time (seconds)', position: 'insideBottom', offset: -5, className: 'text-xs' }}
        />
        <YAxis 
          className="text-xs"
          label={{ value: 'Attention %', angle: -90, position: 'insideLeft', className: 'text-xs' }}
          domain={[0, 100]}
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '0.5rem'
          }}
          formatter={(value: number) => [`${value}%`, 'Attention']}
          labelFormatter={(label) => `${label}s`}
        />
        <Area 
          type="monotone" 
          dataKey="attention" 
          stroke="hsl(var(--primary))" 
          strokeWidth={2}
          fill="url(#attentionGradient)"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
