import { useState } from 'react';
import { useCreateProject } from '../hooks/useQueries';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import type { Industry } from '../backend';
import { Loader2 } from 'lucide-react';

const industries = [
  { value: 'fashionWholesale', label: 'Fashion Wholesale' },
  { value: 'retail', label: 'Retail' },
  { value: 'healthcare', label: 'Healthcare' },
  { value: 'education', label: 'Education' },
  { value: 'realEstate', label: 'Real Estate' },
  { value: 'ecommerce', label: 'E-commerce' },
  { value: 'localServices', label: 'Local Services' },
  { value: 'saas', label: 'SaaS' },
  { value: 'finance', label: 'Finance' },
  { value: 'custom', label: 'Custom' },
];

interface ProjectSetupProps {
  onComplete: () => void;
}

export function ProjectSetup({ onComplete }: ProjectSetupProps) {
  const [projectName, setProjectName] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('');
  const [customIndustry, setCustomIndustry] = useState('');
  const createProject = useCreateProject();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!projectName || !selectedIndustry) return;

    let industry: Industry;
    if (selectedIndustry === 'custom') {
      industry = { __kind__: 'custom', custom: customIndustry || 'Custom Industry' };
    } else {
      industry = { __kind__: selectedIndustry, [selectedIndustry]: null } as Industry;
    }

    await createProject.mutateAsync({
      id: Date.now().toString(),
      name: projectName,
      industry,
    });

    onComplete();
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto">
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-3xl">Create Your Project</CardTitle>
            <CardDescription>
              Set up a new ad testing project to start simulating human behavior
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="projectName">Project Name</Label>
                <Input
                  id="projectName"
                  placeholder="e.g., Summer Campaign 2025"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="industry">Industry</Label>
                <Select value={selectedIndustry} onValueChange={setSelectedIndustry} required>
                  <SelectTrigger id="industry">
                    <SelectValue placeholder="Select your industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {industries.map((industry) => (
                      <SelectItem key={industry.value} value={industry.value}>
                        {industry.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedIndustry === 'custom' && (
                <div className="space-y-2">
                  <Label htmlFor="customIndustry">Custom Industry Name</Label>
                  <Input
                    id="customIndustry"
                    placeholder="Enter your industry"
                    value={customIndustry}
                    onChange={(e) => setCustomIndustry(e.target.value)}
                  />
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={createProject.isPending || !projectName || !selectedIndustry}
              >
                {createProject.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create Project & Add First Ad'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
