import { useState } from 'react';
import type { ProjectView } from '../backend';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Plus } from 'lucide-react';
import { AdCreativeForm } from './AdCreativeForm';
import { AdsList } from './AdsList';
import { AnalyticsDashboard } from './AnalyticsDashboard';

interface DashboardProps {
  project: ProjectView;
  onAddNew: () => void;
}

export function Dashboard({ project, onAddNew }: DashboardProps) {
  const [showAddForm, setShowAddForm] = useState(project.ads.length === 0);
  const [selectedTab, setSelectedTab] = useState('ads');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-3xl font-bold">{project.name}</h1>
            <p className="text-muted-foreground">
              {project.ads.length} {project.ads.length === 1 ? 'ad' : 'ads'} in testing
            </p>
          </div>
          {!showAddForm && (
            <Button onClick={() => setShowAddForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add New Ad
            </Button>
          )}
        </div>
      </div>

      {showAddForm ? (
        <AdCreativeForm
          projectId={project.id}
          onComplete={() => setShowAddForm(false)}
          onCancel={() => project.ads.length > 0 && setShowAddForm(false)}
        />
      ) : (
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="ads">Ad Creatives</TabsTrigger>
            <TabsTrigger value="analytics">Analytics Dashboard</TabsTrigger>
          </TabsList>

          <TabsContent value="ads">
            <AdsList ads={project.ads} />
          </TabsContent>

          <TabsContent value="analytics">
            <AnalyticsDashboard ads={project.ads} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
