import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';
import type { AdMetrics } from '../lib/simulation';

interface MetricsGaugeProps {
  metrics?: AdMetrics;
}

export function MetricsGauge({ metrics }: MetricsGaugeProps) {
  if (!metrics) return null;

  const data = [
    { metric: 'Hook', value: metrics.hookStrength },
    { metric: 'Attention', value: metrics.attentionRate },
    { metric: 'Emotion', value: metrics.emotionalResonance },
    { metric: 'Trust', value: metrics.trustLevel },
    { metric: 'Intent', value: metrics.outboundIntentProbability },
    { metric: 'Clarity', value: 100 - metrics.cognitiveLoad },
  ];

  return (
    <ResponsiveContainer width="100%" height={300}>
      <RadarChart data={data}>
        <PolarGrid className="stroke-muted" />
        <PolarAngleAxis dataKey="metric" className="text-xs" />
        <PolarRadiusAxis angle={90} domain={[0, 100]} className="text-xs" />
        <Radar
          name="Performance"
          dataKey="value"
          stroke="hsl(var(--primary))"
          fill="hsl(var(--primary))"
          fillOpacity={0.6}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}
