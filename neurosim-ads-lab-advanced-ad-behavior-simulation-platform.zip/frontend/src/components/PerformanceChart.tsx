import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { Ad } from '../backend';
import type { AdMetrics } from '../lib/simulation';

interface PerformanceChartProps {
  data: Array<{ ad: Ad; metrics: AdMetrics }>;
}

export function PerformanceChart({ data }: PerformanceChartProps) {
  const chartData = data.map(({ ad, metrics }, index) => ({
    name: `Ad ${index + 1}`,
    'Overall Score': metrics.overallScore,
    'Hook Strength': metrics.hookStrength,
    'Attention Rate': metrics.attentionRate,
    'Intent': metrics.outboundIntentProbability,
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
        <XAxis dataKey="name" className="text-xs" />
        <YAxis className="text-xs" domain={[0, 100]} />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'hsl(var(--card))',
            border: '1px solid hsl(var(--border))',
            borderRadius: '0.5rem'
          }}
        />
        <Legend />
        <Bar dataKey="Overall Score" fill="hsl(var(--chart-1))" />
        <Bar dataKey="Hook Strength" fill="hsl(var(--chart-2))" />
        <Bar dataKey="Attention Rate" fill="hsl(var(--chart-3))" />
        <Bar dataKey="Intent" fill="hsl(var(--chart-4))" />
      </BarChart>
    </ResponsiveContainer>
  );
}
