import type { Ad } from '../backend';

export interface AdMetrics {
  attentionRate: number;
  hookStrength: number;
  holdRate: number;
  cognitiveLoad: number;
  emotionalResonance: number;
  trustLevel: number;
  fatigueRisk: number;
  scrollStopProbability: number;
  outboundIntentProbability: number;
  conversionLikelihood: number;
  overallScore: number;
  recommendation: 'scale' | 'improve' | 'kill';
  attentionDecayCurve: Array<{ time: number; attention: number }>;
  emotionalHeatmap: Array<{ time: number; emotion: number; type: string }>;
  demographicInsights: string[];
}

// Demographic behavioral matrix: age × gender × industry likelihood factors
const DEMOGRAPHIC_MATRIX = {
  '18-24': {
    Male: {
      excitementWeight: 1.3,
      trustWeight: 0.7,
      attentionSpan: 0.8,
      noveltySeek: 1.4,
      conversionImpulse: 1.2,
    },
    Female: {
      excitementWeight: 1.4,
      trustWeight: 0.8,
      attentionSpan: 0.85,
      noveltySeek: 1.3,
      conversionImpulse: 1.1,
    },
    All: {
      excitementWeight: 1.35,
      trustWeight: 0.75,
      attentionSpan: 0.82,
      noveltySeek: 1.35,
      conversionImpulse: 1.15,
    },
  },
  '25-34': {
    Male: {
      excitementWeight: 1.1,
      trustWeight: 0.95,
      attentionSpan: 1.0,
      noveltySeek: 1.1,
      conversionImpulse: 1.0,
    },
    Female: {
      excitementWeight: 1.2,
      trustWeight: 1.0,
      attentionSpan: 1.05,
      noveltySeek: 1.0,
      conversionImpulse: 0.95,
    },
    All: {
      excitementWeight: 1.15,
      trustWeight: 0.97,
      attentionSpan: 1.02,
      noveltySeek: 1.05,
      conversionImpulse: 0.97,
    },
  },
  '35-44': {
    Male: {
      excitementWeight: 0.9,
      trustWeight: 1.15,
      attentionSpan: 1.1,
      noveltySeek: 0.85,
      conversionImpulse: 0.9,
    },
    Female: {
      excitementWeight: 1.0,
      trustWeight: 1.2,
      attentionSpan: 1.15,
      noveltySeek: 0.8,
      conversionImpulse: 0.85,
    },
    All: {
      excitementWeight: 0.95,
      trustWeight: 1.17,
      attentionSpan: 1.12,
      noveltySeek: 0.82,
      conversionImpulse: 0.87,
    },
  },
  '45-54': {
    Male: {
      excitementWeight: 0.75,
      trustWeight: 1.3,
      attentionSpan: 1.2,
      noveltySeek: 0.7,
      conversionImpulse: 0.8,
    },
    Female: {
      excitementWeight: 0.85,
      trustWeight: 1.35,
      attentionSpan: 1.25,
      noveltySeek: 0.65,
      conversionImpulse: 0.75,
    },
    All: {
      excitementWeight: 0.8,
      trustWeight: 1.32,
      attentionSpan: 1.22,
      noveltySeek: 0.67,
      conversionImpulse: 0.77,
    },
  },
  '55+': {
    Male: {
      excitementWeight: 0.6,
      trustWeight: 1.5,
      attentionSpan: 1.3,
      noveltySeek: 0.5,
      conversionImpulse: 0.7,
    },
    Female: {
      excitementWeight: 0.7,
      trustWeight: 1.55,
      attentionSpan: 1.35,
      noveltySeek: 0.45,
      conversionImpulse: 0.65,
    },
    All: {
      excitementWeight: 0.65,
      trustWeight: 1.52,
      attentionSpan: 1.32,
      noveltySeek: 0.47,
      conversionImpulse: 0.67,
    },
  },
};

// Industry-specific behavioral modifiers
const INDUSTRY_MODIFIERS = {
  fashionWholesale: { emotionBoost: 1.2, trustRequirement: 0.9, urgencyFactor: 1.1 },
  retail: { emotionBoost: 1.15, trustRequirement: 0.95, urgencyFactor: 1.05 },
  healthcare: { emotionBoost: 0.9, trustRequirement: 1.4, urgencyFactor: 0.8 },
  education: { emotionBoost: 0.95, trustRequirement: 1.3, urgencyFactor: 0.85 },
  realEstate: { emotionBoost: 1.0, trustRequirement: 1.35, urgencyFactor: 0.9 },
  ecommerce: { emotionBoost: 1.1, trustRequirement: 1.0, urgencyFactor: 1.2 },
  localServices: { emotionBoost: 1.05, trustRequirement: 1.15, urgencyFactor: 0.95 },
  saas: { emotionBoost: 0.85, trustRequirement: 1.25, urgencyFactor: 0.9 },
  finance: { emotionBoost: 0.8, trustRequirement: 1.5, urgencyFactor: 0.75 },
  custom: { emotionBoost: 1.0, trustRequirement: 1.0, urgencyFactor: 1.0 },
};

// Sentiment analysis for emotional mapping
function analyzeSentiment(text: string): { score: number; emotions: string[] } {
  const positiveWords = ['amazing', 'great', 'best', 'love', 'perfect', 'excellent', 'fantastic', 'wonderful', 'incredible', 'awesome', 'beautiful', 'happy', 'joy', 'success', 'win', 'free', 'save', 'new', 'exclusive', 'limited'];
  const urgentWords = ['now', 'today', 'hurry', 'limited', 'exclusive', 'urgent', 'fast', 'quick', 'instant', 'immediately'];
  const trustWords = ['guarantee', 'certified', 'proven', 'trusted', 'secure', 'safe', 'verified', 'authentic', 'professional', 'expert'];
  const emotionalWords = ['feel', 'imagine', 'discover', 'transform', 'change', 'dream', 'deserve', 'experience'];

  const lowerText = text.toLowerCase();
  const words = lowerText.split(/\s+/);

  let positiveCount = 0;
  let urgentCount = 0;
  let trustCount = 0;
  let emotionalCount = 0;

  words.forEach(word => {
    if (positiveWords.some(pw => word.includes(pw))) positiveCount++;
    if (urgentWords.some(uw => word.includes(uw))) urgentCount++;
    if (trustWords.some(tw => word.includes(tw))) trustCount++;
    if (emotionalWords.some(ew => word.includes(ew))) emotionalCount++;
  });

  const totalWords = words.length;
  const sentimentScore = Math.min(100, ((positiveCount + emotionalCount) / totalWords) * 300);

  const emotions: string[] = [];
  if (urgentCount > 0) emotions.push('urgency');
  if (trustCount > 0) emotions.push('trust');
  if (emotionalCount > 0) emotions.push('emotional');
  if (positiveCount > 0) emotions.push('positive');

  return { score: sentimentScore, emotions };
}

// Exponential attention decay model
function calculateAttentionDecay(
  videoLength: number,
  hookStrength: number,
  ageGroup: string,
  engagementFactor: number
): Array<{ time: number; attention: number }> {
  const demographic = DEMOGRAPHIC_MATRIX[ageGroup as keyof typeof DEMOGRAPHIC_MATRIX] || DEMOGRAPHIC_MATRIX['25-34'];
  const attentionSpan = demographic.All.attentionSpan;
  
  const baseDecayRate = 0.15 / attentionSpan;
  const adjustedDecayRate = baseDecayRate * (1 - hookStrength / 200);
  
  const curve: Array<{ time: number; attention: number }> = [];
  const steps = 10;
  const timeStep = videoLength / steps;

  for (let i = 0; i <= steps; i++) {
    const time = i * timeStep;
    const attention = 100 * Math.exp(-adjustedDecayRate * time) * engagementFactor;
    curve.push({
      time: Math.round(time * 10) / 10,
      attention: Math.max(10, Math.min(100, Math.round(attention)))
    });
  }

  return curve;
}

// Emotional response heatmap over time
function generateEmotionalHeatmap(
  videoLength: number,
  sentiment: { score: number; emotions: string[] },
  hookStrength: number,
  demographicFactors: any
): Array<{ time: number; emotion: number; type: string }> {
  const heatmap: Array<{ time: number; emotion: number; type: string }> = [];
  const steps = 10;
  const timeStep = videoLength / steps;

  for (let i = 0; i <= steps; i++) {
    const time = i * timeStep;
    const position = i / steps;

    if (position <= 0.2) {
      const intensity = hookStrength * (1 + position * 2);
      heatmap.push({
        time: Math.round(time * 10) / 10,
        emotion: Math.min(100, intensity),
        type: 'excitement'
      });
    } else if (position <= 0.7) {
      const baseEmotion = sentiment.score * demographicFactors.excitementWeight;
      const variance = Math.sin(position * Math.PI) * 15;
      heatmap.push({
        time: Math.round(time * 10) / 10,
        emotion: Math.max(30, Math.min(100, baseEmotion + variance)),
        type: sentiment.emotions.includes('trust') ? 'trust' : 'interest'
      });
    } else {
      const ctaIntensity = 60 + (demographicFactors.conversionImpulse * 30);
      heatmap.push({
        time: Math.round(time * 10) / 10,
        emotion: Math.min(100, ctaIntensity),
        type: 'action'
      });
    }
  }

  return heatmap;
}

// Calculate cognitive load based on complexity factors
function calculateCognitiveLoad(
  textLength: number,
  headline: string,
  cta: string,
  videoLength: number
): number {
  const textComplexity = Math.min(100, (textLength / 300) * 100);
  const headlineComplexity = Math.min(100, (headline.length / 80) * 100);
  const simpleCTAs = ['Shop Now', 'Learn More', 'Sign Up', 'Get Started', 'Buy Now'];
  const ctaComplexity = simpleCTAs.includes(cta) ? 20 : 50;
  const videoComplexity = videoLength > 60 ? 70 : videoLength > 30 ? 40 : 20;
  
  const cognitiveLoad = (
    textComplexity * 0.35 +
    headlineComplexity * 0.25 +
    ctaComplexity * 0.20 +
    videoComplexity * 0.20
  );
  
  return Math.max(15, Math.min(85, cognitiveLoad));
}

// Calculate trust level with demographic and industry factors
function calculateTrustLevel(
  conversionLocation: string,
  sentiment: { score: number; emotions: string[] },
  industryModifier: any,
  demographicFactors: any
): number {
  const locationTrust = {
    'Website': 75,
    'Lead Form': 80,
    'WhatsApp': 65,
    'Instagram DM': 60
  };
  
  const baseTrust = locationTrust[conversionLocation as keyof typeof locationTrust] || 70;
  const trustBoost = sentiment.emotions.includes('trust') ? 15 : 0;
  const adjustedTrust = baseTrust * demographicFactors.trustWeight * industryModifier.trustRequirement;
  
  return Math.max(40, Math.min(95, adjustedTrust + trustBoost));
}

// Calculate fatigue risk
function calculateFatigueRisk(
  cognitiveLoad: number,
  videoLength: number,
  textLength: number
): number {
  const loadFactor = cognitiveLoad * 0.5;
  const lengthFactor = Math.min(40, (videoLength / 90) * 40);
  const textFactor = Math.min(30, (textLength / 400) * 30);
  
  const fatigueRisk = loadFactor + lengthFactor + textFactor;
  
  return Math.max(10, Math.min(80, fatigueRisk));
}

// Generate demographic-specific insights
function generateDemographicInsights(
  ad: Ad,
  metrics: Partial<AdMetrics>,
  demographicFactors: any,
  industryModifier: any
): string[] {
  const insights: string[] = [];
  
  // Use first age group if multiple selected
  const primaryAgeGroup = ad.targetAgeGroups[0] || '25-34';
  const primaryGender = ad.targetGenders[0] || 'All';
  
  // Age-specific insights
  if (primaryAgeGroup === '18-24') {
    if (demographicFactors.noveltySeek > 1.2) {
      insights.push(`${primaryAgeGroup} ${primaryGender}: High novelty-seeking behavior detected. Creative freshness is critical for this segment.`);
    }
    if (metrics.hookStrength && metrics.hookStrength > 75) {
      insights.push(`${primaryAgeGroup} ${primaryGender}: Strong hook resonates well with younger audiences who value excitement and quick engagement.`);
    }
  } else if (primaryAgeGroup === '55+') {
    if (demographicFactors.trustWeight > 1.4) {
      insights.push(`${primaryAgeGroup} ${primaryGender}: Trust and credibility are paramount for this demographic. Emphasize reliability and proven results.`);
    }
    if (metrics.cognitiveLoad && metrics.cognitiveLoad < 40) {
      insights.push(`${primaryAgeGroup} ${primaryGender}: Clear, simple messaging performs best with this age group's preference for straightforward communication.`);
    }
  } else {
    insights.push(`${primaryAgeGroup} ${primaryGender}: Balanced approach works well. This demographic values both emotional appeal and practical benefits.`);
  }
  
  // Gender-specific insights
  if (primaryGender === 'Female' && metrics.emotionalResonance && metrics.emotionalResonance > 70) {
    insights.push(`Female audience: Strong emotional connection detected. Storytelling and relatable scenarios are highly effective.`);
  } else if (primaryGender === 'Male' && metrics.outboundIntentProbability && metrics.outboundIntentProbability > 70) {
    insights.push(`Male audience: High action intent. Direct, benefit-focused messaging drives conversions effectively.`);
  }
  
  // Multi-country insights
  if (ad.countries.length > 3) {
    insights.push(`Multi-country targeting: Broad geographic reach detected. Consider cultural nuances and localized messaging for optimal performance.`);
  }
  
  // Audience size insights
  const audienceNum = Number(ad.audienceSize);
  if (audienceNum > 50000) {
    insights.push(`Large audience size (${audienceNum.toLocaleString()}): Broad targeting may dilute message relevance. Consider segmentation for better results.`);
  } else if (audienceNum < 5000) {
    insights.push(`Focused audience size (${audienceNum.toLocaleString()}): Highly targeted approach allows for personalized messaging and higher engagement.`);
  }
  
  // Industry-specific insights
  if (industryModifier.trustRequirement > 1.3) {
    insights.push(`Industry insight: High-trust industry requires additional credibility signals (testimonials, certifications, guarantees).`);
  }
  if (industryModifier.urgencyFactor > 1.1) {
    insights.push(`Industry insight: Time-sensitive offers and urgency tactics perform well in this market segment.`);
  }
  
  return insights;
}

// Main simulation function with deep behavioral modeling
export function simulateAdMetrics(ad: Ad): AdMetrics {
  // Get demographic factors - use first selected or default
  const primaryAgeGroup = ad.targetAgeGroups[0] || '25-34';
  const primaryGender = ad.targetGenders[0] || 'All';
  const demographic = DEMOGRAPHIC_MATRIX[primaryAgeGroup as keyof typeof DEMOGRAPHIC_MATRIX] || DEMOGRAPHIC_MATRIX['25-34'];
  const demographicFactors = demographic[primaryGender as keyof typeof demographic] || demographic.All;
  
  // Get industry modifiers
  const industryModifier = INDUSTRY_MODIFIERS.ecommerce;
  
  // Analyze text sentiment
  const textSentiment = analyzeSentiment(ad.primaryText + ' ' + ad.headline);
  
  // Estimate video length
  const estimatedVideoLength = 30;
  
  // Calculate cognitive load
  const cognitiveLoad = calculateCognitiveLoad(
    ad.primaryText.length,
    ad.headline,
    ad.cta,
    estimatedVideoLength
  );
  
  // Hook strength with demographic and sentiment factors
  const baseHookScore = 60 + (ad.headline.length > 20 && ad.headline.length < 60 ? 15 : 0);
  const sentimentBoost = textSentiment.score * 0.2;
  const ctaBoost = ['Shop Now', 'Sign Up', 'Learn More', 'Get Started'].includes(ad.cta) ? 12 : 6;
  const hookStrength = Math.max(35, Math.min(95, 
    (baseHookScore + sentimentBoost + ctaBoost) * demographicFactors.noveltySeek
  ));
  
  // Attention rate with exponential decay consideration
  const baseAttention = hookStrength * 0.85;
  const attentionRate = Math.max(40, Math.min(95, 
    baseAttention * demographicFactors.attentionSpan
  ));
  
  // Hold rate based on engagement and cognitive load
  const textOptimal = ad.primaryText.length > 50 && ad.primaryText.length < 200;
  const baseHoldRate = textOptimal ? 75 : 60;
  const holdRate = Math.max(45, Math.min(90, 
    (baseHoldRate - cognitiveLoad * 0.3) * demographicFactors.attentionSpan
  ));
  
  // Emotional resonance with demographic weighting
  const emotionalGoals = ['Messages', 'Awareness', 'Leads'];
  const emotionBase = emotionalGoals.includes(ad.conversionGoal) ? 70 : 60;
  const emotionalResonance = Math.max(40, Math.min(95, 
    (emotionBase + textSentiment.score * 0.3) * demographicFactors.excitementWeight * industryModifier.emotionBoost
  ));
  
  // Trust level with industry and demographic factors
  const trustLevel = calculateTrustLevel(
    ad.conversionLocation,
    textSentiment,
    industryModifier,
    demographicFactors
  );
  
  // Fatigue risk
  const fatigueRisk = calculateFatigueRisk(
    cognitiveLoad,
    estimatedVideoLength,
    ad.primaryText.length
  );
  
  // Scroll-stop probability
  const scrollStopProbability = Math.max(35, Math.min(95, 
    (hookStrength * 0.6 + attentionRate * 0.4) * (1 + demographicFactors.noveltySeek * 0.1)
  ));
  
  // Outbound intent probability
  const intentGoals = ['Purchases', 'Leads', 'Messages'];
  const intentBase = intentGoals.includes(ad.conversionGoal) ? 65 : 50;
  const urgencyBoost = textSentiment.emotions.includes('urgency') ? 10 : 0;
  const outboundIntentProbability = Math.max(30, Math.min(90, 
    (intentBase + trustLevel * 0.2 + urgencyBoost) * demographicFactors.conversionImpulse * industryModifier.urgencyFactor
  ));
  
  // Conversion likelihood
  const conversionLikelihood = Math.max(25, Math.min(85, 
    outboundIntentProbability * 0.4 +
    trustLevel * 0.3 +
    emotionalResonance * 0.2 +
    (100 - fatigueRisk) * 0.1
  ));
  
  // Overall score
  const overallScore = Math.round(
    hookStrength * 0.18 +
    attentionRate * 0.15 +
    holdRate * 0.12 +
    (100 - cognitiveLoad) * 0.10 +
    emotionalResonance * 0.15 +
    trustLevel * 0.12 +
    scrollStopProbability * 0.08 +
    outboundIntentProbability * 0.10
  );
  
  // Recommendation
  let recommendation: 'scale' | 'improve' | 'kill';
  if (overallScore >= 75) {
    recommendation = 'scale';
  } else if (overallScore >= 55) {
    recommendation = 'improve';
  } else {
    recommendation = 'kill';
  }
  
  // Generate attention decay curve
  const engagementFactor = (emotionalResonance + trustLevel) / 200;
  const attentionDecayCurve = calculateAttentionDecay(
    estimatedVideoLength,
    hookStrength,
    primaryAgeGroup,
    engagementFactor
  );
  
  // Generate emotional heatmap
  const emotionalHeatmap = generateEmotionalHeatmap(
    estimatedVideoLength,
    textSentiment,
    hookStrength,
    demographicFactors
  );
  
  // Generate demographic insights
  const partialMetrics = {
    hookStrength: Math.round(hookStrength),
    cognitiveLoad: Math.round(cognitiveLoad),
    emotionalResonance: Math.round(emotionalResonance),
    outboundIntentProbability: Math.round(outboundIntentProbability),
  };
  const demographicInsights = generateDemographicInsights(
    ad,
    partialMetrics,
    demographicFactors,
    industryModifier
  );
  
  return {
    attentionRate: Math.round(attentionRate),
    hookStrength: Math.round(hookStrength),
    holdRate: Math.round(holdRate),
    cognitiveLoad: Math.round(cognitiveLoad),
    emotionalResonance: Math.round(emotionalResonance),
    trustLevel: Math.round(trustLevel),
    fatigueRisk: Math.round(fatigueRisk),
    scrollStopProbability: Math.round(scrollStopProbability),
    outboundIntentProbability: Math.round(outboundIntentProbability),
    conversionLikelihood: Math.round(conversionLikelihood),
    overallScore,
    recommendation,
    attentionDecayCurve,
    emotionalHeatmap,
    demographicInsights,
  };
}

